import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { fileURLToPath } from "node:url";

const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)));
const siteRoot = path.resolve(appRoot, "site");
const DEFAULT_PORT = 60064;
const host = "0.0.0.0";

function parsePortValue(raw) {
  const trimmed = String(raw || "").trim();
  if (!trimmed) return null;
  const parsed = Number.parseInt(trimmed, 10);
  if (!Number.isFinite(parsed) || parsed <= 0 || parsed > 65535) {
    return null;
  }
  return parsed;
}

function getPortFromArguments() {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--port" && i + 1 < argv.length) {
      const parsed = parsePortValue(argv[i + 1]);
      if (parsed) return parsed;
    }
    if (arg.startsWith("--port=")) {
      const parsed = parsePortValue(arg.slice("--port=".length));
      if (parsed) return parsed;
    }
  }

  return null;
}


const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".ttf": "font/ttf"
};

async function askPort(defaultPort = DEFAULT_PORT) {
  const envPort = parsePortValue(process.env.MUSIC_ARCHIVER_PORT || process.env.PORT);
  if (envPort) return envPort;

  const argPort = getPortFromArguments();
  if (argPort) return argPort;

  if (process.env.MUSIC_ARCHIVER_NO_PROMPT === "1" || !process.stdin.isTTY) {
    return defaultPort;
  }

  const rl = readline.createInterface({ input, output });
  try {
    const answer = await rl.question(`Which port should the server use? [${defaultPort}] `);
    const trimmed = String(answer || '').trim();
    const parsed = parsePortValue(trimmed);
    if (!parsed) {
      console.log(`Invalid port "${trimmed}". Falling back to ${defaultPort}.`);
      return defaultPort;
    }
    return parsed;
  } finally {
    rl.close();
  }
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, headers);
  res.end(body);
}

function withCors(origin = "*") {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
    "Access-Control-Max-Age": "86400"
  };
}

async function readFileSafe(filePath) {
  try {
    return await fs.readFile(filePath);
  } catch {
    return null;
  }
}

function toBase64(buffer) {
  return Buffer.from(buffer).toString("base64");
}

function fromBase64(base64) {
  return Buffer.from(base64, "base64");
}

function normalizeHeaders(headers = {}) {
  const out = {};
  for (const [key, value] of Object.entries(headers)) {
    if (value == null) continue;
    out[key] = String(value);
  }
  return out;
}

function rewriteProxyHeaders(headers) {
  const normalized = normalizeHeaders(headers);
  const out = new Headers();
  for (const [key, value] of Object.entries(normalized)) {
    const lower = key.toLowerCase();

    if (lower === "x-override-user-agent") {
      out.set("user-agent", value);
      continue;
    }
    if (lower === "x-override-origin") {
      out.set("origin", value);
      continue;
    }

    try {
      out.set(key, value);
    } catch {
      // Ignore forbidden or unsupported headers.
    }
  }
  return out;
}

function sanitizeFilename(input) {
  const raw = String(input || "").trim() || "download.bin";
  return raw.replace(/[\/:*?"<>|]+/g, "_");
}

function contentDisposition(filename) {
  const safe = sanitizeFilename(filename);
  return `attachment; filename="${safe.replace(/\"/g, "_")}"; filename*=UTF-8''${encodeURIComponent(safe)}`;
}

function downloadHeaders(filename, upstream) {
  const headers = {
    "Content-Disposition": contentDisposition(filename),
    "Cache-Control": "no-store"
  };

  const passThrough = [
    "content-type",
    "content-length",
    "accept-ranges",
    "content-range",
    "etag",
    "last-modified",
    "cache-control"
  ];

  for (const key of passThrough) {
    const value = upstream.headers.get(key);
    if (value) headers[key] = value;
  }

  if (!headers["content-type"]) {
    headers["content-type"] = "application/octet-stream";
  }

  return headers;
}

async function handleDownload(req, res, reqUrl) {
  const url = reqUrl.searchParams.get("url");
  const filename = reqUrl.searchParams.get("filename") || "download.bin";

  if (!url) {
    send(res, 400, "Missing url", { "Content-Type": "text/plain; charset=utf-8" });
    return;
  }

  let upstream;
  try {
    const upstreamHeaders = new Headers({
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
      "referer": "https://www.youtube.com/",
      "origin": "https://www.youtube.com"
    });

    const range = req.headers.range;
    if (range) upstreamHeaders.set("range", range);

    upstream = await fetch(url, {
      method: req.method,
      redirect: "follow",
      headers: upstreamHeaders
    });
  } catch (error) {
    send(res, 502, JSON.stringify({ ok: false, error: error?.message || String(error) }), {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    });
    return;
  }

  if (!upstream.ok && upstream.status !== 206) {
    const text = await upstream.text().catch(() => "");
    send(res, upstream.status, JSON.stringify({ ok: false, error: text || upstream.statusText || "Upstream fetch failed" }), {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    });
    return;
  }

  if (req.method === "HEAD") {
    res.writeHead(upstream.status, downloadHeaders(filename, upstream));
    res.end();
    return;
  }

  res.writeHead(upstream.status, downloadHeaders(filename, upstream));
  if (!upstream.body) {
    res.end();
    return;
  }

  Readable.fromWeb(upstream.body).pipe(res);
}

async function handleProxy(req, res) {
  const origin = req.headers.origin || "*";
  const cors = withCors(origin === "null" ? "*" : origin);

  if (req.method === "OPTIONS") {
    send(res, 204, "", cors);
    return;
  }

  if (req.method !== "POST") {
    send(res, 405, JSON.stringify({ ok: false, error: "Use POST" }), {
      ...cors,
      "Content-Type": "application/json; charset=utf-8"
    });
    return;
  }

  let raw = "";
  for await (const chunk of req) raw += chunk;

  let payload;
  try {
    payload = JSON.parse(raw || "{}");
  } catch (error) {
    send(res, 400, JSON.stringify({ ok: false, error: "Invalid JSON body" }), {
      ...cors,
      "Content-Type": "application/json; charset=utf-8"
    });
    return;
  }

  const { url, method = "GET", headers = {}, bodyText, bodyBase64, responseType = "text", credentials = "omit" } = payload;
  if (!url) {
    send(res, 400, JSON.stringify({ ok: false, error: "Missing url" }), {
      ...cors,
      "Content-Type": "application/json; charset=utf-8"
    });
    return;
  }

  const init = {
    method,
    redirect: "follow",
    credentials,
    headers: rewriteProxyHeaders(headers)
  };

  if (bodyText != null) {
    init.body = bodyText;
  } else if (bodyBase64 != null) {
    init.body = fromBase64(bodyBase64);
  }

  try {
    const response = await fetch(url, init);
    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key] = value;
    });

    let body;
    let bodyEncoding = "text";
    if (responseType === "arrayBuffer" || responseType === "binary") {
      body = toBase64(await response.arrayBuffer());
      bodyEncoding = "base64";
    } else {
      body = await response.text();
    }

    send(res, 200, JSON.stringify({
      ok: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      body,
      bodyEncoding,
      finalUrl: response.url
    }), {
      ...cors,
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    });
  } catch (error) {
    send(res, 502, JSON.stringify({ ok: false, error: error?.message || String(error) }), {
      ...cors,
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    });
  }
}

const server = http.createServer(async (req, res) => {
  const reqUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = decodeURIComponent(reqUrl.pathname);

  if (pathname === "/proxy") {
    await handleProxy(req, res);
    return;
  }

  if (pathname === "/download") {
    await handleDownload(req, res, reqUrl);
    return;
  }

  let filePath;
  if (pathname === "/") {
    filePath = path.join(siteRoot, "index.html");
  } else if (pathname === "/musiclib.html") {
    filePath = path.join(appRoot, "musiclib.html");
  } else {
    filePath = path.join(siteRoot, pathname);
  }

  const isUnderSite = filePath.startsWith(siteRoot + path.sep) || filePath === siteRoot;
  const isUnderApp = filePath.startsWith(appRoot + path.sep) || filePath === appRoot;
  if (!isUnderSite && !isUnderApp) {
    send(res, 403, "Forbidden");
    return;
  }

  const data = await readFileSafe(filePath);
  if (!data) {
    send(res, 404, "Not found");
    return;
  }

  const ext = path.extname(filePath).toLowerCase();
  send(res, 200, data, {
    "Content-Type": mime[ext] || "application/octet-stream",
    "Cache-Control": "no-store"
  });
});

const port = await askPort();

server.listen(port, host, () => {
  console.log(`Serving ${siteRoot} at http://localhost:${port}/`);
  console.log(`Local proxy endpoint: http://localhost:${port}/proxy`);
  console.log(`Local download endpoint: http://localhost:${port}/download`);
});
