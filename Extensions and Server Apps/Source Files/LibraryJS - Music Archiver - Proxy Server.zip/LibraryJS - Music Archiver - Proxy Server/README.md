# Music Archiver for LibraryJS

Run `node server.mjs` to test the server, then load the `extension/` folder as an unpacked extension.

On the first click after installation, the extension will ask for the Music Storage URL plus the Music Proxy URL and port. Those values are saved and reused on later clicks.

## What this build does

- Fetches `/youtubei/v1/next` and `/youtubei/v1/player` through the extension bridge
- Parses `streamingData.formats` and `streamingData.adaptiveFormats`
- Shows separate stream lists for:
  - muxed video + audio
  - video-only
  - audio-only
- Lets you choose a stream and download it through a local `/download` endpoint

## Notes

- The stream list uses direct media URLs found in the player response.
- Downloads go through the local Node server so Chrome does not try to fetch the remote media URL directly.
- The MusicLib target page and proxy origin are configurable instead of being hardcoded to a single LAN IP.

## Self-contained Windows tray build

This folder now builds into a single Windows EXE that starts the local server and manages a tray icon.

The browser extension is still loaded separately in Chrome or Edge, but the launcher itself is now one self-contained executable.

### Build it

1. Open PowerShell in this folder on Windows.
2. Run `powershell -ExecutionPolicy Bypass -File .\build-sea.ps1`.
3. Launch `dist\MusicArchiver.exe`.

The EXE opens the local app in your browser. Minimizing the window hides it to the system tray instead of keeping a taskbar button. The tray launcher now also includes startup options for launching with Windows and auto-starting the server on the saved port.
