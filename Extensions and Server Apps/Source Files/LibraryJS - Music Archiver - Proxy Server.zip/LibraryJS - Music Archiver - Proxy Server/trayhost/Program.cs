using System.Diagnostics;
using System.Drawing;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;
using System.Windows.Forms;

namespace MusicArchiverTrayHost;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MusicArchiverContext());
    }
}

internal sealed class MusicArchiverContext : ApplicationContext
{
    private const string StartupRunValueName = "Music Archiver";

    private readonly NotifyIcon _trayIcon;
    private readonly MainWindow _window;
    private readonly CancellationTokenSource _shutdown = new();
    private readonly Icon _appIcon;
    private readonly AppSettingsStore _settings = AppSettingsStore.Load();

    private Process? _serverProcess;
    private string? _runtimeRoot;
    private string? _serverUrl;
    private bool _exitRequested;
    private bool _startupInProgress;
    private bool _serverRunning;
    private bool _autoStartAttempted;

    public MusicArchiverContext()
    {
        _appIcon = LoadAppIcon();

        _window = new MainWindow(_settings.Port, _appIcon);
        _window.Icon = _appIcon;
        _window.RequestStart += async (_, port) => await StartAsync(port);
        _window.RequestExit += (_, _) => ExitApplication();
        _window.PortChanged += (_, port) =>
        {
            _settings.Port = port;
            _settings.Save();
        };
        _window.StartWithWindowsChanged += (_, enabled) =>
        {
            try
            {
                SetStartupRegistration(enabled);
                _settings.StartWithWindows = enabled;
                _settings.Save();
            }
            catch (Exception ex)
            {
                _window.SetStartupOptionSilently(_settings.StartWithWindows);
                MessageBox.Show(_window, ex.Message, "Music Archiver", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };
        _window.AutoStartServerChanged += (_, enabled) =>
        {
            _settings.AutoStartServerOnLaunch = enabled;
            _settings.Save();
        };
        _window.MinimizeWhenStartedChanged += (_, enabled) =>
        {
            _settings.MinimizeWhenStarted = enabled;
            _settings.Save();
        };
        _window.Resize += Window_Resize;
        _window.FormClosing += Window_FormClosing;
        _window.Shown += Window_Shown;

        _window.SetStartupOptions(_settings.StartWithWindows, _settings.AutoStartServerOnLaunch, _settings.MinimizeWhenStarted);
        _window.SetStatus("Choose a port and start the local server.");

        _trayIcon = new NotifyIcon
        {
            Icon = _appIcon,
            Text = "Music Archiver",
            Visible = true,
            ContextMenuStrip = BuildTrayMenu()
        };
        _trayIcon.DoubleClick += (_, _) => RestoreWindow();

        _window.Show();
    }

    private async void Window_Shown(object? sender, EventArgs e)
    {
        if (_autoStartAttempted || !_settings.AutoStartServerOnLaunch)
        {
            return;
        }

        _autoStartAttempted = true;

        if (_window.IsDisposed)
        {
            return;
        }

        await Task.Delay(750).ConfigureAwait(true);

        if (_window.IsDisposed)
        {
            return;
        }

        _settings.Save();
        _window.SetStatus($"Auto-start is enabled. Starting on saved port {_settings.Port}...");
        _window.SetStatusDetail("The launcher is using the last port from your saved settings.");
        await StartAsync(_settings.Port);
    }

    private static Icon LoadAppIcon()
    {
        try
        {
            var assembly = Assembly.GetExecutingAssembly();
            using var stream = assembly.GetManifestResourceStream("MusicArchiver.ico");
            if (stream is not null)
            {
                return new Icon(stream);
            }
        }
        catch
        {
            // Fall through to the default system icon.
        }

        return System.Drawing.SystemIcons.Application;
    }

    private ContextMenuStrip BuildTrayMenu()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open Music Archiver", null, (_, _) => RestoreWindow());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => ExitApplication());
        return menu;
    }

    private async Task StartAsync(int port)
    {
        if (_startupInProgress || _serverRunning)
        {
            return;
        }

        _startupInProgress = true;
        _settings.Port = port;
        _settings.Save();

        _window.SetUiEnabled(false);
        _window.SetStatus("Preparing the bundled runtime...");

        try
        {
            _runtimeRoot = Path.Combine(Path.GetTempPath(), "music-archiver-tray-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_runtimeRoot);

            ExtractBundledFiles(_runtimeRoot);

            _serverUrl = $"http://127.0.0.1:{port}/";

            _window.SetStatus($"Starting the local server on port {port}...");
            _serverProcess = StartServer(_runtimeRoot, port);
            _serverProcess.Exited += (_, _) => HandleServerExited();

            await WaitForServerAsync(_serverUrl, _shutdown.Token).ConfigureAwait(true);

            _serverRunning = true;
            _window.SetStartButtonState(true);
            _window.SetStatus($"Server ready on port {port}.");
            _window.SetStatusDetail("The server is running and available from the tray icon.");
            if (_settings.MinimizeWhenStarted)
            {
                _window.WindowState = FormWindowState.Minimized;
            }
            else
            {
                _window.SetStatus("Server started.");
            }
        }
        catch (OperationCanceledException)
        {
            // Normal shutdown.
        }
        catch (Exception ex)
        {
            _window.SetStatus("Startup failed.");
            _window.SetStatusDetail("The server could not be started.");
            MessageBox.Show(_window, ex.ToString(), "Music Archiver startup failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _window.SetStartButtonState(false);
            _window.SetUiEnabled(true);
        }
        finally
        {
            _startupInProgress = false;
            if (!_serverRunning)
            {
                _window.SetStartButtonState(false);
                _window.SetUiEnabled(true);
            }
        }
    }

    private void HandleServerExited()
    {
        if (_exitRequested)
        {
            return;
        }

        try
        {
            _window.BeginInvoke(new Action(() =>
            {
                _window.SetStatus("The local server stopped unexpectedly.");
                MessageBox.Show(_window, "The local server stopped unexpectedly.", "Music Archiver", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ExitApplication();
            }));
        }
        catch
        {
            // Ignore UI shutdown issues.
        }
    }

    private void Window_Resize(object? sender, EventArgs e)
    {
        if (_window.WindowState != FormWindowState.Minimized)
        {
            return;
        }

        _window.Hide();
        _trayIcon.Visible = true;
        _trayIcon.ShowBalloonTip(1000, "Music Archiver", _serverRunning
            ? "Still running in the system tray."
            : "The launcher is hidden in the system tray.", ToolTipIcon.Info);
    }

    private void Window_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_exitRequested)
        {
            return;
        }

        e.Cancel = true;
        _window.BeginInvoke(new Action(ExitApplication));
    }

    private void RestoreWindow()
    {
        if (_window.IsDisposed)
        {
            return;
        }

        if (!_window.Visible)
        {
            _window.Show();
        }

        if (_window.WindowState == FormWindowState.Minimized)
        {
            _window.WindowState = FormWindowState.Normal;
        }

        _window.ShowInTaskbar = true;
        _window.BringToFront();
        _window.Activate();
    }

    private void OpenBrowser()
    {
        if (string.IsNullOrWhiteSpace(_serverUrl))
        {
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo(_serverUrl)
            {
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            _window.SetStatus("Unable to open the browser.");
            MessageBox.Show(_window, ex.Message, "Music Archiver", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private Process StartServer(string runtimeRoot, int port)
    {
        var nodePath = Path.Combine(runtimeRoot, "node.exe");
        var serverPath = Path.Combine(runtimeRoot, "server.mjs");

        if (!File.Exists(nodePath))
        {
            throw new FileNotFoundException("Bundled node.exe was not found.", nodePath);
        }

        if (!File.Exists(serverPath))
        {
            throw new FileNotFoundException("Bundled server.mjs was not found.", serverPath);
        }

        var startInfo = new ProcessStartInfo
        {
            FileName = nodePath,
            Arguments = $"\"{serverPath}\" --port {port}",
            WorkingDirectory = runtimeRoot,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        startInfo.Environment["MUSIC_ARCHIVER_PORT"] = port.ToString();
        startInfo.Environment["MUSIC_ARCHIVER_NO_PROMPT"] = "1";

        var process = new Process
        {
            StartInfo = startInfo,
            EnableRaisingEvents = true
        };

        var outputBuffer = new StringBuilder();
        process.OutputDataReceived += (_, args) =>
        {
            if (!string.IsNullOrWhiteSpace(args.Data))
            {
                outputBuffer.AppendLine(args.Data);
            }
        };
        process.ErrorDataReceived += (_, args) =>
        {
            if (!string.IsNullOrWhiteSpace(args.Data))
            {
                outputBuffer.AppendLine(args.Data);
            }
        };

        if (!process.Start())
        {
            throw new InvalidOperationException("Failed to start the bundled server process.");
        }

        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        return process;
    }

    private static async Task WaitForServerAsync(string url, CancellationToken cancellationToken)
    {
        using var http = new HttpClient(new HttpClientHandler
        {
            UseProxy = false
        })
        {
            Timeout = TimeSpan.FromSeconds(2)
        };

        for (var attempt = 0; attempt < 80; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            try
            {
                using var response = await http.GetAsync(url, cancellationToken).ConfigureAwait(true);
                if (response.IsSuccessStatusCode)
                {
                    return;
                }
            }
            catch
            {
                // Keep waiting until the local server is ready.
            }

            await Task.Delay(250, cancellationToken).ConfigureAwait(true);
        }

        throw new TimeoutException("The local server did not become ready in time.");
    }

    private static void ExtractBundledFiles(string runtimeRoot)
    {
        var assembly = Assembly.GetExecutingAssembly();
        foreach (var resourceName in assembly.GetManifestResourceNames())
        {
            var relativePath = TryMapResourceToRelativePath(resourceName);
            if (relativePath is null)
            {
                continue;
            }

            var destinationPath = Path.Combine(runtimeRoot, relativePath);
            Directory.CreateDirectory(Path.GetDirectoryName(destinationPath)!);

            using var stream = assembly.GetManifestResourceStream(resourceName);
            if (stream is null)
            {
                continue;
            }

            using var output = File.Create(destinationPath);
            stream.CopyTo(output);
        }
    }

    private static string? TryMapResourceToRelativePath(string resourceName)
    {
        var normalized = resourceName.Replace('\\', '/').TrimStart('/');

        if (normalized.Equals("node.exe", StringComparison.OrdinalIgnoreCase))
        {
            return "node.exe";
        }

        if (normalized.Equals("server.mjs", StringComparison.OrdinalIgnoreCase))
        {
            return "server.mjs";
        }

        if (normalized.Equals("musiclib.html", StringComparison.OrdinalIgnoreCase))
        {
            return "musiclib.html";
        }

        if (normalized.StartsWith("site/", StringComparison.OrdinalIgnoreCase))
        {
            return normalized;
        }

        return null;
    }

    private void SetStartupRegistration(bool enabled)
    {
        using var key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true)
            ?? throw new InvalidOperationException("Could not open the Windows startup registry key.");

        var command = $"\"{GetCurrentExecutablePath()}\"";
        if (enabled)
        {
            key.SetValue(StartupRunValueName, command, RegistryValueKind.String);
        }
        else
        {
            key.DeleteValue(StartupRunValueName, false);
        }
    }

    private static string GetCurrentExecutablePath()
    {
        var processPath = Environment.ProcessPath;
        if (!string.IsNullOrWhiteSpace(processPath))
        {
            return processPath;
        }

        var baseDirectory = AppContext.BaseDirectory;
        if (!string.IsNullOrWhiteSpace(baseDirectory))
        {
            var exeName = Assembly.GetEntryAssembly()?.GetName().Name;
            if (!string.IsNullOrWhiteSpace(exeName))
            {
                var candidate = Path.Combine(baseDirectory, exeName + ".exe");
                if (File.Exists(candidate))
                {
                    return candidate;
                }
            }
        }

        throw new InvalidOperationException("Unable to determine the current executable path.");
    }

    private void ExitApplication()
    {
        _exitRequested = true;
        _shutdown.Cancel();

        try
        {
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
        }
        catch
        {
            // Ignore tray cleanup failures.
        }

        try
        {
            if (_serverProcess is not null && !_serverProcess.HasExited)
            {
                _serverProcess.Kill(entireProcessTree: true);
                _serverProcess.Dispose();
            }
        }
        catch
        {
            // Ignore process cleanup failures.
        }

        try
        {
            if (!string.IsNullOrWhiteSpace(_runtimeRoot) && Directory.Exists(_runtimeRoot))
            {
                Directory.Delete(_runtimeRoot, recursive: true);
            }
        }
        catch
        {
            // Ignore temp cleanup failures.
        }

        try
        {
            _window.Dispose();
        }
        catch
        {
            // Ignore window cleanup failures.
        }

        try
        {
            _appIcon.Dispose();
        }
        catch
        {
            // Ignore icon cleanup failures.
        }

        ExitThread();
    }
}

internal delegate void PortRequestedEventHandler(object? sender, int port);
internal delegate void BoolSettingChangedEventHandler(object? sender, bool value);

internal sealed class MainWindow : Form
{
    private readonly Label _statusLabel;
    private readonly Label _statusDetailLabel;
    private readonly NumericUpDown _portUpDown;
    private readonly Button _startButton;
    private readonly Button _exitButton;
    private readonly CheckBox _startWithWindowsCheckBox;
    private readonly CheckBox _autoStartServerCheckBox;
    private readonly CheckBox _minimizeWhenStartedCheckBox;
    private bool _suppressSettingEvents;

    public event PortRequestedEventHandler? RequestStart;
    public event EventHandler? RequestExit;
    public event PortRequestedEventHandler? PortChanged;
    public event BoolSettingChangedEventHandler? StartWithWindowsChanged;
    public event BoolSettingChangedEventHandler? AutoStartServerChanged;
    public event BoolSettingChangedEventHandler? MinimizeWhenStartedChanged;

    public MainWindow(int defaultPort, Icon appIcon)
    {
        Text = "Music Archiver";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = true;
        ShowInTaskbar = true;
        ClientSize = new System.Drawing.Size(1120, 860);
        BackColor = Color.FromArgb(15, 23, 25);
        Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        ForeColor = Color.FromArgb(240, 245, 242);
        AutoScaleMode = AutoScaleMode.Font;

        var headerPanel = new Panel
        {
            Left = 0,
            Top = 0,
            Width = ClientSize.Width,
            Height = 108,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = Color.FromArgb(20, 32, 34),
            Padding = new Padding(20, 16, 20, 16)
        };

        var iconBox = new PictureBox
        {
            Left = 20,
            Top = 16,
            Width = 52,
            Height = 52,
            SizeMode = PictureBoxSizeMode.CenterImage,
            Image = appIcon.ToBitmap(),
            BackColor = Color.FromArgb(33, 52, 54)
        };
        iconBox.Paint += (_, e) =>
        {
            using var pen = new Pen(Color.FromArgb(64, 165, 109), 2);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.DrawRectangle(pen, 1, 1, iconBox.Width - 3, iconBox.Height - 3);
        };

        var titleLabel = new Label
        {
            Left = 86,
            Top = 15,
            Width = 820,
            Height = 26,
            Text = "Music Archiver",
            Font = new Font(Font.FontFamily, 14F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 248, 247)
        };

        var subtitleLabel = new Label
        {
            Left = 86,
            Top = 42,
            Width = 900,
            Height = 30,
            Text = "Start the bundled local server, keep it in the tray, and let Windows bring it back automatically.",
            ForeColor = Color.FromArgb(183, 201, 198)
        };

        headerPanel.Controls.Add(iconBox);
        headerPanel.Controls.Add(titleLabel);
        headerPanel.Controls.Add(subtitleLabel);

        var bodyPanel = new Panel
        {
            Left = 20,
            Top = 124,
            Width = ClientSize.Width - 40,
            Height = 460,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = Color.FromArgb(20, 32, 34),
            Padding = new Padding(18)
        };

        var startupTitle = new Label
        {
            Left = 18,
            Top = 14,
            Width = 220,
            Height = 22,
            Text = "Startup options",
            Font = new Font(Font.FontFamily, 10.5F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 248, 247)
        };

        _startWithWindowsCheckBox = new CheckBox
        {
            Left = 18,
            Top = 50,
            Width = 680,
            Height = 30,
            Text = "Start Music Archiver when Windows starts",
            ForeColor = Color.FromArgb(240, 245, 242),
            FlatStyle = FlatStyle.Flat,
            AutoSize = false
        };
        _startWithWindowsCheckBox.FlatAppearance.BorderColor = Color.FromArgb(64, 165, 109);

        _autoStartServerCheckBox = new CheckBox
        {
            Left = 18,
            Top = 88,
            Width = 680,
            Height = 36,
            Text = "Start the server automatically when Music Archiver opens",
            ForeColor = Color.FromArgb(240, 245, 242),
            FlatStyle = FlatStyle.Flat,
            AutoSize = false
        };
        _autoStartServerCheckBox.FlatAppearance.BorderColor = Color.FromArgb(64, 165, 109);

        _minimizeWhenStartedCheckBox = new CheckBox
        {
            Left = 18,
            Top = 126,
            Width = 680,
            Height = 30,
            Text = "Minimized when Started",
            ForeColor = Color.FromArgb(240, 245, 242),
            FlatStyle = FlatStyle.Flat,
            AutoSize = false
        };
        _minimizeWhenStartedCheckBox.FlatAppearance.BorderColor = Color.FromArgb(64, 165, 109);

        var startupHint = new Label
        {
            Left = 42,
            Top = 164,
            Width = 640,
            Height = 40,
            Text = "The selected port is saved automatically, and auto-start will use that same port on launch.",
            ForeColor = Color.FromArgb(183, 201, 198)
        };

        var portLabel = new Label
        {
            Left = 18,
            Top = 226,
            Width = 180,
            Height = 22,
            Text = "Local server port",
            Font = new Font(Font.FontFamily, 10.0F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 248, 247)
        };

        _portUpDown = new NumericUpDown
        {
            Left = 18,
            Top = 252,
            Width = 140,
            Minimum = 1,
            Maximum = 65535,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.FromArgb(14, 24, 26),
            ForeColor = Color.FromArgb(240, 245, 242),
            Value = ClampPort(defaultPort)
        };

        var portHint = new Label
        {
            Left = 170,
            Top = 254,
            Width = 460,
            Height = 22,
            Text = "This port is saved for the next launch.",
            ForeColor = Color.FromArgb(183, 201, 198)
        };

        bodyPanel.Controls.Add(startupTitle);
        bodyPanel.Controls.Add(_startWithWindowsCheckBox);
        bodyPanel.Controls.Add(_autoStartServerCheckBox);
        bodyPanel.Controls.Add(_minimizeWhenStartedCheckBox);
        bodyPanel.Controls.Add(startupHint);
        bodyPanel.Controls.Add(portLabel);
        bodyPanel.Controls.Add(_portUpDown);
        bodyPanel.Controls.Add(portHint);

        var buttonPanel = new Panel
        {
            Left = 20,
            Top = 778,
            Width = ClientSize.Width - 40,
            Height = 42,
            Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = Color.Transparent
        };

        _startButton = CreateActionButton("Start server", 840, 0, 160, Color.FromArgb(64, 165, 109));
        _startButton.Click += (_, _) => RequestStart?.Invoke(this, (int)_portUpDown.Value);

        _exitButton = CreateActionButton("Exit", 1010, 0, 80, Color.FromArgb(46, 62, 63));
        _exitButton.Click += (_, _) => RequestExit?.Invoke(this, EventArgs.Empty);

        buttonPanel.Controls.Add(_startButton);
        buttonPanel.Controls.Add(_exitButton);

        _statusLabel = new Label
        {
            Left = 20,
            Top = 716,
            Width = ClientSize.Width - 40,
            Height = 18,
            Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            Text = "Ready to start.",
            ForeColor = Color.FromArgb(240, 245, 242)
        };

        _statusDetailLabel = new Label
        {
            Left = 20,
            Top = 742,
            Width = ClientSize.Width - 40,
            Height = 18,
            Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            Text = "The app will stay in the system tray once the server is running.",
            ForeColor = Color.FromArgb(183, 201, 198)
        };

        _portUpDown.ValueChanged += (_, _) =>
        {
            if (_suppressSettingEvents)
            {
                return;
            }

            PortChanged?.Invoke(this, (int)_portUpDown.Value);
        };

        _startWithWindowsCheckBox.CheckedChanged += (_, _) =>
        {
            if (_suppressSettingEvents)
            {
                return;
            }

            StartWithWindowsChanged?.Invoke(this, _startWithWindowsCheckBox.Checked);
        };

        _autoStartServerCheckBox.CheckedChanged += (_, _) =>
        {
            if (_suppressSettingEvents)
            {
                return;
            }

            AutoStartServerChanged?.Invoke(this, _autoStartServerCheckBox.Checked);
        };

        _minimizeWhenStartedCheckBox.CheckedChanged += (_, _) =>
        {
            if (_suppressSettingEvents)
            {
                return;
            }

            MinimizeWhenStartedChanged?.Invoke(this, _minimizeWhenStartedCheckBox.Checked);
        };

        Controls.Add(headerPanel);
        Controls.Add(bodyPanel);
        Controls.Add(_statusLabel);
        Controls.Add(_statusDetailLabel);
        Controls.Add(buttonPanel);
    }

    private Button CreateActionButton(string text, int left, int top, int width, Color backColor)
    {
        var button = new Button
        {
            Text = text,
            Left = left,
            Top = top,
            Width = width,
            Height = 34,
            BackColor = backColor,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font(Font.FontFamily, 9.25F, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    public void SetStatus(string text)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStatus(text)));
            return;
        }

        _statusLabel.Text = text;
    }

    public void SetStatusDetail(string text)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStatusDetail(text)));
            return;
        }

        _statusDetailLabel.Text = text;
    }

    public void SetUiEnabled(bool enabled)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetUiEnabled(enabled)));
            return;
        }

        _portUpDown.Enabled = enabled;
        _startButton.Enabled = enabled;
    }


    public void SetStartButtonState(bool started)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStartButtonState(started)));
            return;
        }

        _startButton.Text = started ? "Started" : "Start server";
        _startButton.Enabled = !started;
    }

    public void SetStartupOptions(bool startWithWindows, bool autoStartServer, bool minimizeWhenStarted)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStartupOptions(startWithWindows, autoStartServer, minimizeWhenStarted)));
            return;
        }

        _suppressSettingEvents = true;
        try
        {
            _startWithWindowsCheckBox.Checked = startWithWindows;
            _autoStartServerCheckBox.Checked = autoStartServer;
            _minimizeWhenStartedCheckBox.Checked = minimizeWhenStarted;
        }
        finally
        {
            _suppressSettingEvents = false;
        }
    }

    public void SetStartupOptionSilently(bool startWithWindows)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStartupOptionSilently(startWithWindows)));
            return;
        }

        _suppressSettingEvents = true;
        try
        {
            _startWithWindowsCheckBox.Checked = startWithWindows;
        }
        finally
        {
            _suppressSettingEvents = false;
        }
    }

    private static decimal ClampPort(int port)
    {
        if (port < 1)
        {
            return 1;
        }

        if (port > 65535)
        {
            return 65535;
        }

        return port;
    }
}

internal sealed class AppSettings
{
    public int Port { get; set; } = 60064;
    public bool StartWithWindows { get; set; }
    public bool AutoStartServerOnLaunch { get; set; }
    public bool MinimizeWhenStarted { get; set; }
}

internal sealed class AppSettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    private AppSettingsStore(AppSettings settings, string path)
    {
        Settings = settings;
        Path = path;
    }

    public AppSettings Settings { get; }
    public string Path { get; }

    public int Port
    {
        get => Settings.Port;
        set => Settings.Port = ClampPort(value);
    }

    public bool StartWithWindows
    {
        get => Settings.StartWithWindows;
        set => Settings.StartWithWindows = value;
    }

    public bool AutoStartServerOnLaunch
    {
        get => Settings.AutoStartServerOnLaunch;
        set => Settings.AutoStartServerOnLaunch = value;
    }

    public bool MinimizeWhenStarted
    {
        get => Settings.MinimizeWhenStarted;
        set => Settings.MinimizeWhenStarted = value;
    }

    public static AppSettingsStore Load()
    {
        var path = GetPath();
        try
        {
            if (File.Exists(path))
            {
                var json = File.ReadAllText(path);
                var settings = JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
                settings.Port = ClampPort(settings.Port);
                return new AppSettingsStore(settings, path);
            }
        }
        catch
        {
            // Ignore corrupted settings and fall back to defaults.
        }

        return new AppSettingsStore(new AppSettings(), path);
    }

    public void Save()
    {
        var dir = System.IO.Path.GetDirectoryName(Path);
        if (!string.IsNullOrWhiteSpace(dir))
        {
            Directory.CreateDirectory(dir);
        }

        var json = JsonSerializer.Serialize(Settings, JsonOptions);
        File.WriteAllText(Path, json, Encoding.UTF8);
    }

    private static string GetPath()
    {
        var root = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        return System.IO.Path.Combine(root, "Music Archiver", "settings.json");
    }

    private static int ClampPort(int port)
    {
        if (port < 1)
        {
            return 1;
        }

        if (port > 65535)
        {
            return 65535;
        }

        return port;
    }
}
